
document.addEventListener("DOMContentLoaded", function() { 


const acciones = ['Deposito', 'Retiro', 'Pago', 'Saldo'];
const dolares = [200, 350, 400, 1200];


const ctx = document.getElementById('myChart').getContext('2d');

const myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: acciones,
        datasets: [{
            label: 'Dólares',
            data: dolares,
            backgroundColor: [
                'rgba(247, 71, 33, 0.2)',
                'rgba(39, 247, 33, 0.2)',
                'rgba(33, 59, 247, 0.2)',
                'rgba(231, 252, 16, 0.2)',
            ],
            borderColor: [
                'rgba(247, 71, 33, 1)',
                'rgba(39, 247, 33, 1)',
                'rgba(33, 59, 247, 1)',
                'rgba(231, 252, 16, 1)',
            ],
            borderWidth: 1.5
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});




    
});

